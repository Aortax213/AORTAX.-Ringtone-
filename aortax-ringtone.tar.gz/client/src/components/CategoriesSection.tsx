import CategoryCard from "./CategoryCard";
import { type Category } from "@shared/schema";

interface CategoriesSectionProps {
  categories: Category[];
  onCategoryClick?: (categoryId: string) => void;
}

export default function CategoriesSection({ categories, onCategoryClick }: CategoriesSectionProps) {
  return (
    <section className="py-12 md:py-16 bg-muted/30">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold mb-8" data-testid="text-categories-title">
          تصفح حسب الفئة
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {categories.map((category) => (
            <CategoryCard
              key={category.id}
              name={category.name}
              nameAr={category.nameAr}
              count={category.count}
              imageUrl={category.imageUrl}
              onClick={() => onCategoryClick?.(category.id)}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
