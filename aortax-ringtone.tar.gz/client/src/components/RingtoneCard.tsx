import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Download, Heart, Play, Star } from "lucide-react";
import { useState } from "react";

interface RingtoneCardProps {
  id: string;
  title: string;
  category: string;
  duration: number;
  downloads: number;
  rating: number;
  isPlaying?: boolean;
  isFavorite?: boolean;
  onPlay?: () => void;
  onDownload?: () => void;
  onFavorite?: () => void;
}

export default function RingtoneCard({
  id,
  title,
  category,
  duration,
  downloads,
  rating,
  isPlaying = false,
  isFavorite: initialFavorite = false,
  onPlay,
  onDownload,
  onFavorite,
}: RingtoneCardProps) {
  const [isFavorite, setIsFavorite] = useState(initialFavorite);

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const formatDownloads = (count: number) => {
    if (count >= 1000000) return `${(count / 1000000).toFixed(1)}M`;
    if (count >= 1000) return `${(count / 1000).toFixed(1)}K`;
    return count.toString();
  };

  const handleFavorite = () => {
    setIsFavorite(!isFavorite);
    onFavorite?.();
  };

  return (
    <Card className="group overflow-hidden hover-elevate transition-all duration-200" data-testid={`card-ringtone-${id}`}>
      <div className="p-4">
        <div className="relative h-32 mb-3 rounded-md bg-gradient-to-br from-primary/20 via-chart-2/20 to-chart-3/20 flex items-center justify-center overflow-hidden">
          <div className="absolute inset-0 flex items-center justify-center gap-0.5 opacity-40">
            {Array.from({ length: 40 }).map((_, i) => (
              <div
                key={i}
                className="w-1 bg-primary rounded-full transition-all duration-300"
                style={{
                  height: `${Math.random() * 60 + 20}%`,
                  animation: isPlaying ? `pulse ${Math.random() * 0.5 + 0.5}s ease-in-out infinite` : 'none'
                }}
              />
            ))}
          </div>
          <Button
            size="icon"
            variant="default"
            className="relative z-10 h-14 w-14 rounded-full shadow-lg"
            onClick={onPlay}
            data-testid={`button-play-${id}`}
          >
            <Play className="h-6 w-6" fill="currentColor" />
          </Button>
        </div>

        <div className="space-y-2">
          <div className="flex items-start justify-between gap-2">
            <h3 className="font-semibold text-base line-clamp-2 flex-1" data-testid={`text-ringtone-title-${id}`}>
              {title}
            </h3>
            <Button
              size="icon"
              variant="ghost"
              className="h-8 w-8 shrink-0"
              onClick={handleFavorite}
              data-testid={`button-favorite-${id}`}
            >
              <Heart className={`h-4 w-4 ${isFavorite ? 'fill-destructive text-destructive' : ''}`} />
            </Button>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <Badge variant="secondary" className="text-xs" data-testid={`badge-category-${id}`}>
              {category}
            </Badge>
            <span className="text-xs text-muted-foreground">{formatDuration(duration)}</span>
          </div>

          <div className="flex items-center justify-between pt-2">
            <div className="flex items-center gap-3 text-xs text-muted-foreground">
              <div className="flex items-center gap-1">
                <Download className="h-3.5 w-3.5" />
                <span data-testid={`text-downloads-${id}`}>{formatDownloads(downloads)}</span>
              </div>
              <div className="flex items-center gap-1">
                <Star className="h-3.5 w-3.5 fill-chart-3 text-chart-3" />
                <span data-testid={`text-rating-${id}`}>{rating.toFixed(1)}</span>
              </div>
            </div>
            <Button
              size="sm"
              variant="outline"
              className="h-7 text-xs"
              onClick={onDownload}
              data-testid={`button-download-${id}`}
            >
              <Download className="h-3 w-3 ml-1" />
              تحميل
            </Button>
          </div>
        </div>
      </div>
    </Card>
  );
}
