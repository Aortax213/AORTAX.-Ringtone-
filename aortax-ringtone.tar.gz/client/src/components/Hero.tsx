import SearchBar from "./SearchBar";
import { Badge } from "@/components/ui/badge";
import { Download } from "lucide-react";
import heroImg from '@assets/generated_images/Hero_waveform_background_6bc81a82.png';

interface HeroProps {
  onSearch?: (query: string) => void;
}

export default function Hero({ onSearch }: HeroProps) {
  return (
    <div className="relative h-[80vh] flex items-center justify-center overflow-hidden">
      <img
        src={heroImg}
        alt="AORTAX Ringtone Background"
        className="absolute inset-0 w-full h-full object-cover"
      />
      <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/40 to-background" />
      
      <div className="relative z-10 container mx-auto px-4 text-center">
        <Badge
          variant="secondary"
          className="mb-6 bg-primary/10 text-primary border-primary/20 backdrop-blur-sm text-sm px-4 py-2"
          data-testid="badge-download-count"
        >
          <Download className="h-3.5 w-3.5 ml-1" />
          أكثر من 2 مليون تحميل
        </Badge>
        
        <h1 className="text-5xl md:text-7xl font-bold text-white mb-4 drop-shadow-2xl" data-testid="text-hero-title">
          AORTAX
        </h1>
        <p className="text-xl md:text-2xl text-white/90 mb-8 drop-shadow-lg max-w-2xl mx-auto" data-testid="text-hero-subtitle">
          أفضل نغمات الهاتف الاحترافية
        </p>
        <p className="text-base md:text-lg text-white/80 mb-10 drop-shadow-lg max-w-xl mx-auto">
          اكتشف مكتبة شاملة من النغمات العصرية والكلاسيكية - تحميل مجاني بجودة عالية
        </p>
        
        <SearchBar onSearch={onSearch} placeholder="ابحث عن نغمتك المثالية..." />
      </div>
    </div>
  );
}
