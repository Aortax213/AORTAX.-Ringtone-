import { Card } from "@/components/ui/card";
import { Music2 } from "lucide-react";

interface CategoryCardProps {
  name: string;
  nameAr: string;
  count: number;
  imageUrl: string;
  onClick?: () => void;
}

export default function CategoryCard({ nameAr, count, imageUrl, onClick }: CategoryCardProps) {
  return (
    <Card
      onClick={onClick}
      className="group cursor-pointer overflow-hidden hover-elevate active-elevate-2 transition-transform duration-200"
      data-testid={`card-category-${nameAr}`}
    >
      <div className="relative h-44">
        <img
          src={imageUrl}
          alt={nameAr}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent" />
        <div className="absolute bottom-0 right-0 left-0 p-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold text-white mb-1" data-testid={`text-category-name-${nameAr}`}>
                {nameAr}
              </h3>
              <p className="text-sm text-white/80" data-testid={`text-category-count-${nameAr}`}>
                {count} نغمة
              </p>
            </div>
            <Music2 className="h-6 w-6 text-white/80" />
          </div>
        </div>
      </div>
    </Card>
  );
}
