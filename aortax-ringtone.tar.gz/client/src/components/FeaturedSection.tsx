import RingtoneCard from "./RingtoneCard";
import { type Ringtone } from "@shared/schema";

interface FeaturedSectionProps {
  ringtones: Ringtone[];
  onPlay?: (id: string) => void;
  onDownload?: (id: string) => void;
  playingId?: string;
}

export default function FeaturedSection({ ringtones, onPlay, onDownload, playingId }: FeaturedSectionProps) {
  return (
    <section className="py-12 md:py-16">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-3xl md:text-4xl font-bold" data-testid="text-featured-title">
            النغمات المميزة
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {ringtones.map((ringtone) => (
            <RingtoneCard
              key={ringtone.id}
              id={ringtone.id}
              title={ringtone.title}
              category={ringtone.category}
              duration={ringtone.duration}
              downloads={ringtone.downloads}
              rating={ringtone.rating}
              isPlaying={playingId === ringtone.id}
              onPlay={() => onPlay?.(ringtone.id)}
              onDownload={() => onDownload?.(ringtone.id)}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
