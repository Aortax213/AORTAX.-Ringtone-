import TrendingSection from '../TrendingSection';

export default function TrendingSectionExample() {
  const mockRingtones = [
    { id: '1', title: 'نغمة الأذان الجميلة', category: 'إسلامية', duration: 45, downloads: 125000, rating: 5.0, audioUrl: '', waveformData: null },
    { id: '2', title: 'صوت المطر والرعد', category: 'طبيعة', duration: 30, downloads: 98000, rating: 4.9, audioUrl: '', waveformData: null },
    { id: '3', title: 'نغمة البيانو الكلاسيكية', category: 'كلاسيك', duration: 28, downloads: 87000, rating: 4.8, audioUrl: '', waveformData: null },
    { id: '4', title: 'إيقاع إلكتروني حديث', category: 'عصرية', duration: 25, downloads: 76000, rating: 4.7, audioUrl: '', waveformData: null },
    { id: '5', title: 'أصوات الطيور الصباحية', category: 'طبيعة', duration: 35, downloads: 65000, rating: 4.8, audioUrl: '', waveformData: null },
  ];

  return (
    <div className="bg-background">
      <TrendingSection
        ringtones={mockRingtones}
        onPlay={(id) => console.log('Play:', id)}
        onDownload={(id) => console.log('Download:', id)}
      />
    </div>
  );
}
