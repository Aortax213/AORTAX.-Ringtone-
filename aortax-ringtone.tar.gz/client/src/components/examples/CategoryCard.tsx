import CategoryCard from '../CategoryCard';
import musicImg from '@assets/generated_images/Music_category_image_f6687f4f.png';

export default function CategoryCardExample() {
  return (
    <div className="p-8 bg-background max-w-sm">
      <CategoryCard
        name="Music"
        nameAr="موسيقى"
        count={245}
        imageUrl={musicImg}
        onClick={() => console.log('Category clicked')}
      />
    </div>
  );
}
