import CategoriesSection from '../CategoriesSection';
import musicImg from '@assets/generated_images/Music_category_image_f6687f4f.png';
import natureImg from '@assets/generated_images/Nature_category_image_2bcd2f05.png';
import classicImg from '@assets/generated_images/Classic_category_image_9a823817.png';
import modernImg from '@assets/generated_images/Modern_category_image_2cd219d9.png';

export default function CategoriesSectionExample() {
  const mockCategories = [
    { id: '1', name: 'Music', nameAr: 'موسيقى', count: 245, icon: 'music', imageUrl: musicImg },
    { id: '2', name: 'Nature', nameAr: 'طبيعة', count: 128, icon: 'leaf', imageUrl: natureImg },
    { id: '3', name: 'Classic', nameAr: 'كلاسيك', count: 96, icon: 'clock', imageUrl: classicImg },
    { id: '4', name: 'Modern', nameAr: 'عصرية', count: 187, icon: 'zap', imageUrl: modernImg },
  ];

  return (
    <div className="bg-background">
      <CategoriesSection
        categories={mockCategories}
        onCategoryClick={(id) => console.log('Category clicked:', id)}
      />
    </div>
  );
}
