import RingtoneCard from '../RingtoneCard';

export default function RingtoneCardExample() {
  return (
    <div className="p-8 bg-background max-w-sm">
      <RingtoneCard
        id="1"
        title="نغمة الصباح الجميلة"
        category="موسيقى"
        duration={28}
        downloads={15420}
        rating={4.8}
        onPlay={() => console.log('Play clicked')}
        onDownload={() => console.log('Download clicked')}
        onFavorite={() => console.log('Favorite toggled')}
      />
    </div>
  );
}
