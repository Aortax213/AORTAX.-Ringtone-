import FeaturedSection from '../FeaturedSection';

export default function FeaturedSectionExample() {
  const mockRingtones = [
    { id: '1', title: 'نغمة الصباح الجميلة', category: 'موسيقى', duration: 28, downloads: 15420, rating: 4.8, audioUrl: '', waveformData: null },
    { id: '2', title: 'صوت الطبيعة الهادئ', category: 'طبيعة', duration: 32, downloads: 8900, rating: 4.6, audioUrl: '', waveformData: null },
    { id: '3', title: 'نغمة كلاسيكية أنيقة', category: 'كلاسيك', duration: 25, downloads: 12300, rating: 4.9, audioUrl: '', waveformData: null },
    { id: '4', title: 'إيقاع عصري نابض', category: 'عصرية', duration: 30, downloads: 21500, rating: 4.7, audioUrl: '', waveformData: null },
  ];

  return (
    <div className="bg-background">
      <FeaturedSection
        ringtones={mockRingtones}
        onPlay={(id) => console.log('Play:', id)}
        onDownload={(id) => console.log('Download:', id)}
      />
    </div>
  );
}
