import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Play, Download, TrendingUp } from "lucide-react";
import { type Ringtone } from "@shared/schema";

interface TrendingSectionProps {
  ringtones: Ringtone[];
  onPlay?: (id: string) => void;
  onDownload?: (id: string) => void;
  playingId?: string;
}

export default function TrendingSection({ ringtones, onPlay, onDownload, playingId }: TrendingSectionProps) {
  const formatDownloads = (count: number) => {
    if (count >= 1000000) return `${(count / 1000000).toFixed(1)}M`;
    if (count >= 1000) return `${(count / 1000).toFixed(1)}K`;
    return count.toString();
  };

  return (
    <section className="py-12 md:py-16">
      <div className="container mx-auto px-4">
        <div className="flex items-center gap-2 mb-8">
          <TrendingUp className="h-8 w-8 text-chart-3" />
          <h2 className="text-3xl md:text-4xl font-bold" data-testid="text-trending-title">
            الأكثر رواجاً
          </h2>
        </div>

        <div className="grid gap-4">
          {ringtones.map((ringtone, index) => (
            <Card key={ringtone.id} className="p-4 hover-elevate" data-testid={`card-trending-${ringtone.id}`}>
              <div className="flex items-center gap-4">
                <div className="text-2xl font-bold text-muted-foreground w-8 text-center">
                  {index + 1}
                </div>

                <Button
                  size="icon"
                  variant="default"
                  className="h-12 w-12 shrink-0"
                  onClick={() => onPlay?.(ringtone.id)}
                  data-testid={`button-play-trending-${ringtone.id}`}
                >
                  <Play className={`h-5 w-5 ${playingId === ringtone.id ? 'animate-pulse' : ''}`} fill="currentColor" />
                </Button>

                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-base mb-1 truncate" data-testid={`text-trending-title-${ringtone.id}`}>
                    {ringtone.title}
                  </h3>
                  <div className="flex items-center gap-2 flex-wrap">
                    <Badge variant="secondary" className="text-xs">
                      {ringtone.category}
                    </Badge>
                    <span className="text-xs text-muted-foreground">
                      {formatDownloads(ringtone.downloads)} تحميل
                    </span>
                  </div>
                </div>

                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onDownload?.(ringtone.id)}
                  data-testid={`button-download-trending-${ringtone.id}`}
                >
                  <Download className="h-4 w-4 ml-1" />
                  تحميل
                </Button>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
