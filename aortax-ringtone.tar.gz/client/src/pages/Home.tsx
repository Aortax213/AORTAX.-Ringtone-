import { useState } from "react";
import Header from "@/components/Header";
import Hero from "@/components/Hero";
import CategoriesSection from "@/components/CategoriesSection";
import FeaturedSection from "@/components/FeaturedSection";
import TrendingSection from "@/components/TrendingSection";
import { SiInstagram } from "react-icons/si";
import musicImg from '@assets/generated_images/Music_category_image_f6687f4f.png';
import natureImg from '@assets/generated_images/Nature_category_image_2bcd2f05.png';
import classicImg from '@assets/generated_images/Classic_category_image_9a823817.png';
import modernImg from '@assets/generated_images/Modern_category_image_2cd219d9.png';
import islamicImg from '@assets/generated_images/Islamic_category_image_628e3e5e.png';

export default function Home() {
  const [playingId, setPlayingId] = useState<string | null>(null);

  const mockCategories = [
    { id: '1', name: 'Music', nameAr: 'موسيقى', count: 245, icon: 'music', imageUrl: musicImg },
    { id: '2', name: 'Nature', nameAr: 'طبيعة', count: 128, icon: 'leaf', imageUrl: natureImg },
    { id: '3', name: 'Classic', nameAr: 'كلاسيك', count: 96, icon: 'clock', imageUrl: classicImg },
    { id: '4', name: 'Modern', nameAr: 'عصرية', count: 187, icon: 'zap', imageUrl: modernImg },
    { id: '5', name: 'Islamic', nameAr: 'إسلامية', count: 156, icon: 'mosque', imageUrl: islamicImg },
  ];

  const mockFeaturedRingtones = [
    { id: '1', title: 'نغمة الصباح الجميلة', category: 'موسيقى', duration: 28, downloads: 15420, rating: 4.8, audioUrl: '', waveformData: null },
    { id: '2', title: 'صوت الطبيعة الهادئ', category: 'طبيعة', duration: 32, downloads: 8900, rating: 4.6, audioUrl: '', waveformData: null },
    { id: '3', title: 'نغمة كلاسيكية أنيقة', category: 'كلاسيك', duration: 25, downloads: 12300, rating: 4.9, audioUrl: '', waveformData: null },
    { id: '4', title: 'إيقاع عصري نابض', category: 'عصرية', duration: 30, downloads: 21500, rating: 4.7, audioUrl: '', waveformData: null },
    { id: '5', title: 'نغمة الأذان المباركة', category: 'إسلامية', duration: 45, downloads: 32100, rating: 5.0, audioUrl: '', waveformData: null },
    { id: '6', title: 'موجات البحر الساحرة', category: 'طبيعة', duration: 35, downloads: 9800, rating: 4.5, audioUrl: '', waveformData: null },
    { id: '7', title: 'سيمفونية موتسارت', category: 'كلاسيك', duration: 40, downloads: 7600, rating: 4.8, audioUrl: '', waveformData: null },
    { id: '8', title: 'بيت إلكتروني حماسي', category: 'عصرية', duration: 27, downloads: 18900, rating: 4.6, audioUrl: '', waveformData: null },
  ];

  const mockTrendingRingtones = [
    { id: '11', title: 'نغمة الأذان الجميلة', category: 'إسلامية', duration: 45, downloads: 125000, rating: 5.0, audioUrl: '', waveformData: null },
    { id: '12', title: 'صوت المطر والرعد', category: 'طبيعة', duration: 30, downloads: 98000, rating: 4.9, audioUrl: '', waveformData: null },
    { id: '13', title: 'نغمة البيانو الكلاسيكية', category: 'كلاسيك', duration: 28, downloads: 87000, rating: 4.8, audioUrl: '', waveformData: null },
    { id: '14', title: 'إيقاع إلكتروني حديث', category: 'عصرية', duration: 25, downloads: 76000, rating: 4.7, audioUrl: '', waveformData: null },
    { id: '15', title: 'أصوات الطيور الصباحية', category: 'طبيعة', duration: 35, downloads: 65000, rating: 4.8, audioUrl: '', waveformData: null },
  ];

  const handleSearch = (query: string) => {
    console.log('Search query:', query);
  };

  const handlePlay = (id: string) => {
    setPlayingId(playingId === id ? null : id);
    console.log('Playing ringtone:', id);
  };

  const handleDownload = (id: string) => {
    console.log('Downloading ringtone:', id);
  };

  const handleCategoryClick = (categoryId: string) => {
    console.log('Category clicked:', categoryId);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Hero onSearch={handleSearch} />
      <CategoriesSection categories={mockCategories} onCategoryClick={handleCategoryClick} />
      <FeaturedSection
        ringtones={mockFeaturedRingtones}
        onPlay={handlePlay}
        onDownload={handleDownload}
        playingId={playingId || undefined}
      />
      <TrendingSection
        ringtones={mockTrendingRingtones}
        onPlay={handlePlay}
        onDownload={handleDownload}
        playingId={playingId || undefined}
      />
      
      <footer className="py-12 border-t border-border bg-muted/20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
            <div>
              <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
                <span className="bg-gradient-to-r from-primary to-chart-2 bg-clip-text text-transparent">
                  AORTAX
                </span>
              </h3>
              <p className="text-sm text-muted-foreground">
                أفضل مكتبة نغمات احترافية للهاتف - تحميل مجاني بجودة عالية
              </p>
            </div>

            <div>
              <h3 className="font-semibold text-base mb-4">روابط سريعة</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <a href="#categories" className="hover:text-foreground transition-colors hover-elevate px-2 py-1 rounded inline-block">
                    الفئات
                  </a>
                </li>
                <li>
                  <a href="#featured" className="hover:text-foreground transition-colors hover-elevate px-2 py-1 rounded inline-block">
                    النغمات المميزة
                  </a>
                </li>
                <li>
                  <a href="#trending" className="hover:text-foreground transition-colors hover-elevate px-2 py-1 rounded inline-block">
                    الأكثر رواجاً
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold text-base mb-4">تابعنا</h3>
              <div className="flex items-center gap-3">
                <a
                  href="https://instagram.com/okba_bzg"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group"
                  data-testid="link-instagram-footer"
                  aria-label="Instagram okba_bzg"
                >
                  <div className="flex items-center gap-2 bg-gradient-to-br from-purple-500 via-pink-500 to-orange-500 p-3 rounded-lg hover-elevate active-elevate-2 transition-all shadow-md">
                    <SiInstagram className="h-5 w-5 text-white" />
                    <span className="text-white font-medium text-sm">@okba_bzg</span>
                  </div>
                </a>
              </div>
              <p className="text-xs text-muted-foreground mt-3">
                للحصول على آخر التحديثات والنغمات الجديدة
              </p>
            </div>
          </div>

          <div className="pt-6 border-t border-border text-center text-sm text-muted-foreground">
            <p>© 2024 AORTAX Ringtone. جميع الحقوق محفوظة.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
